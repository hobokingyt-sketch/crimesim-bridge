# Criminal Simulation

Bridge fixture revision 1. The map remains the world; UI remains the command OS.
